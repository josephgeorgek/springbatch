package sample.jira.export;
public class Test {

    public void getTest(){
        System.out.println("-----getTest");
    }
    
}
